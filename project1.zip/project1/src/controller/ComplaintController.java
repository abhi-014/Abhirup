package com.PROJECT1.controller;

import com.PROJECt1.entity.Complaint;
import com.PROJECt1.entity.Student;
import com.PROJECt1.service.ComplaintService;
import com.PROJECt1.service.StudentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@Rest Controller
@RequestMapping("/complaints")
public class ComplaintController {

    @Autowired
    private ComplaintService complaintService;

    @Autowired
    private StudentService studentService;

    // Show form to create a complaint
    @GetMapping("/add")
    public String showAddComplaintForm(Model model) {
        model.addAttribute("complaint", new Complaint());
        model.addAttribute("students", studentService.getAllStudents()); // For dropdown selection
        return "add_complaint"; // HTML page: add_complaint.html
    }

    // Save complaint
    @PostMapping("/save")
    public String saveComplaint(@ModelAttribute("complaint") Complaint complaint) {
        complaint.setComplaintDate(LocalDateTime.now());
        complaint.setStatus("Pending");
        complaintService.saveComplaint(complaint);
        return "redirect:/complaints/list";
    }

    // List all complaints
    @GetMapping("/list")
    public String listAllComplaints(Model model) {
        List<Complaint> complaints = complaintService.getAllComplaints();
        model.addAttribute("complaints", complaints);
        return "list_complaints"; // HTML page: list_complaints.html
    }

    // View complaints by student ID
    @GetMapping("/student/{id}")
    public String listComplaintsByStudent(@PathVariable("id") Long studentId, Model model) {
        Student student = studentService.getStudentById(studentId);
        List<Complaint> complaints = complaintService.getComplaintsByStudentId(studentId);
        model.addAttribute("student", student);
        model.addAttribute("complaints", complaints);
        return "student_complaints"; // HTML page: student_complaints.html
    }

    // Update complaint status
    @PostMapping("/resolve/{id}")
    public String markAsResolved(@PathVariable("id") Long id) {
        Complaint complaint = complaintService.getComplaintById(id);
        if (complaint != null) {
            complaint.setStatus("Resolved");
            complaintService.saveComplaint(complaint);
        }
        return "redirect:/complaints/list";
    }
}
