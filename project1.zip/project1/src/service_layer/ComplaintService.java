package com.PROJECt1.service_layer;

import com.PROJECt1.entity_layer.Complaint;

import java.util.List;

public interface ComplaintService {
    Complaint saveComplaint(Complaint complaint);
    Complaint getComplaintById(Long id);
    List<Complaint> getAllComplaints();
    List<Complaint> getComplaintsByStudentId(Long studentId);
}
