package com.PROJECt1.service_layer;

import com.PROJECt1.entity_layer.Student;

import java.util.List;

public interface StudentService {
    Student saveStudent(Student student);
    Student getStudentById(Long id);
    List<Student> getAllStudents();
}
